#ifndef _EVEN_H
#define _EVEN_H

#include <stdbool.h>

bool is_even_sorted(int array[], unsigned int length);

#endif
