#include "sorted.h"

unsigned int sorted_until(int array[], unsigned int size) {
    // -- Completar --
    return 0;
}

