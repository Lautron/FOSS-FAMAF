/*
  @file sort.c
  @brief sort functions implementation
*/
#include <stdbool.h>
#include <assert.h>
#include "helpers.h"
#include "sort.h"
#include "movie.h"


bool goes_before(movie_t s1, movie_t s2) {
    // -- Completar --
    return false;
}

unsigned int array_sorted_until(movie_t movielist[], unsigned int size) {
    // -- Completar --
    return 0;
}

