#ifndef _SORTED_H
#define _SORTED_H

unsigned int sorted_until(int array[], unsigned int size);

#endif
