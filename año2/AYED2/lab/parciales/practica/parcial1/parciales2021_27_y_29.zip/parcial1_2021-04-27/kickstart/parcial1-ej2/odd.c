#include <stdbool.h>

#include "odd.h"

bool is_odd_sorted(int array[], unsigned int length) {
    // -- Completar --
    return false;
}

