#ifndef _ODD_H
#define _ODD_H

#include <stdbool.h>

bool is_odd_sorted(int array[], unsigned int length);

#endif
