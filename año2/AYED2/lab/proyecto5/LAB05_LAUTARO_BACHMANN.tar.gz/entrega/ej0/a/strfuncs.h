#ifndef STRFUNCS
#define STRFUNCS 1
#include <stdio.h>

size_t string_length(const char* str);
char* string_filter(const char* str, char c);

#endif /* ifndef STRFUNCS */
