#ifndef MYBOOL
#define MYBOOL 1

#define true 1
#define false 0

typedef int mybool;
#endif /* ifndef MYBOOL */
