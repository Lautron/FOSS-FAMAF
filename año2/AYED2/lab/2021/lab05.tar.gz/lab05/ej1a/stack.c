#include <stdlib.h>
#include <assert.h>
#include "stack.h"
 
